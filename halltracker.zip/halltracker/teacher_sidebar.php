<?php 
 include('connect.php');

 ?>

 
        <div class="left-sidebar">
            
            <div class="scroll-sidebar">
                
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a href="teacher_panel.php" aria-expanded="false"><i class="fa fa-window-maximize"></i>Dashboard</a>
                        <li> <a href="view_teachers_course_responsibility.php" aria-expanded="false"><i class="fa fa-newspaper-o"></i>Course Responsibility</a>
                        </li> 
                        <li> <a href="view_students_marks_by_course_code.php" aria-expanded="false"><i class="fa fa-graduation-cap"></i>Students Marks</a>
                        <li> <a href="view_attendance_by_room_no.php" aria-expanded="false"><i class="fa fa-newspaper-o"></i>Attendance</a>
                        </li>    
                        <li> <a href="view_questions_teacher.php" aria-expanded="false"><i class="fa fa-newspaper-o"></i>View Questions</a> </li>
                        <li> <a class="has-arrow" href="logout.php" ><i class="fa fa-sign-out"></i>Logout</a>
                            
                        </li>          
                    </ul>   
                </nav>
                




            </div>
           
        </div>
        