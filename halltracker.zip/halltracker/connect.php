<?php

$conn = oci_connect("halltracker_admin", "1234", "//localhost:/XEPDB1");

if (!$conn) {
    echo "Connection failed ";
}

?> 