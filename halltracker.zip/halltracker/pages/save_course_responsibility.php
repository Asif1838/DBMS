
<?php
include('../connect.php');
session_start();
extract($_POST);

function exceptions_error_handler($severity, $message, $filename, $lineno) {
      throw new Exception("Already assigned to the course");
}
set_error_handler('exceptions_error_handler');

try {
      $sql = "INSERT INTO COURSES_RESPONSIBILITY (course_code,teacher_id,section) VALUES ('$course_code','$teacher_id','$section')";
   $parse = oci_parse($conn,$sql);
   $t = oci_execute($parse);
   $r = oci_commit($conn);
   $_SESSION['success']=' Record Successfully Added';
}

catch(Exception $e){ 
      $_SESSION['error']= $e->getMessage();
}

?>

<script type="text/javascript">
window.location="../view_course_responsibility.php";
</script>





