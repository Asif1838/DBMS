
<?php
include('../connect.php');
session_start();
$passw = hash('sha256', $_POST['password']);

function createSalt()
{
    return '2123293dsj2hu2nikhiljdsd';
}
$salt = createSalt();
$pass = hash('sha256', $salt . $passw);
$_POST['password'] = $pass;
$user_type = "Student";

function exceptions_error_handler($severity, $message, $filename, $lineno) {
    throw new Exception("A student with the same info exists");
}
set_error_handler('exceptions_error_handler');

extract($_POST);
try{
   $sql = "INSERT INTO student (student_name, student_email, student_contact_no) VALUES ('" . $student_name . "', '" . $student_email . "', '" . $student_contact_no . "')";
   $parse = oci_parse($conn,$sql);
   $r = oci_execute($parse);
   $sql = "INSERT INTO login (email, password, user_type) VALUES ('" . $student_email . "', '" . $password . "', '" . $user_type . "')";
   $parse = oci_parse($conn,$sql);
   $r = oci_execute($parse);

   $r = oci_commit($conn);
   oci_close($conn);
 
    $_SESSION['success']=' Record Successfully Added';
}
catch(Exception $e)
{
      $_SESSION['error']= $e->getMessage();
}
?>
<script type="text/javascript">
window.location="../view_student.php";
</script>
